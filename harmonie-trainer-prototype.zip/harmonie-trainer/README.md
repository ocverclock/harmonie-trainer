# Harmonie Trainer — Prototype jouable

Prototype iPhone/iPad sous forme de PWA, sans compte ni collecte de données. Jeu « Construis l'accord » : 28 accords et 3 niveaux, puis vue « Glissements des voix » pour Dm7→G7→Cmaj7 avec quatre voix colorées. Version de développement, non publiée sur App Store.

## Lancer

```bash
python3 -m http.server 8080
```

Ouvrir http://localhost:8080. Aucun paquet npm n’est nécessaire pour cette version statique. Pour voir depuis un iPhone sur le même réseau, l'URL doit être accessible par HTTPS pour les fonctionnalités PWA et service worker. Pour déployer la version statique, publier directement les fichiers du dossier sur un hébergement HTTPS (ex. GitHub Pages ou Cloudflare Pages). Le build Vite est optionnel et nécessite `npm install` puis `npm run build`. Tester l'installation iOS sur un vrai appareil après publication HTTPS.

## Tests

`npm test` vérifie le corpus, les équivalences d'octaves, les scores de note et les trajectoires. La vérification de compilation Vite est optionnelle et nécessite les dépendances npm. Les contrôles VoiceOver, PWA offline et audio Safari iOS demandent une recette physique.

## Architecture

- `src/music.js` : théorie musicale, corpus et progression fixe, indépendant de l'interface.
- `src/main.js` : jeu et vue interactive responsive, même jeu de données musical partout.
- `src/audio.js` : synthèse Web Audio minimale après interaction.
- `src/style.css` : présentation adaptative au mobile/tablette.
- `sw.js`, `manifest.webmanifest` : installation et cache PWA.

## Limites connues

Le jeu est un prototype sans tests automatiques E2E, sans audio de piano échantillonné et sans synchronisation multi-appareil. Le score se conserve dans `localStorage` du navigateur courant ; une suppression des données de Safari peut le perdre. Le service worker de production ne pré-cache pas explicitement tous les chunks Vite au moment de l'installation ; visiter chaque écran en ligne avant le test hors ligne. Une évolution nécessaire avant livraison publique est un pré-cache de tous les fichiers générés (plugin PWA ou manifeste de build).

Le clavier de quiz sélectionne des classes de notes (C3 et C4 représentent le même choix), tandis que la vue Glissements utilise des notes avec octave. Les voix Dm7→G7→Cmaj7 sont définies manuellement et ne prétendent pas être des voicings automatiquement optimisés. Les couleurs sont accompagnées de labels. Les diagrammes SVG sont pédagogiques, non des partitions.
