export const NOTE_NAMES=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];
export const PITCH={C:0,'C#':1,Db:1,D:2,'D#':3,Eb:3,E:4,F:5,'F#':6,Gb:6,G:7,'G#':8,Ab:8,A:9,'A#':10,Bb:10,B:11};
export const QUALITY={major:[0,4,7],minor:[0,3,7],dim:[0,3,6],aug:[0,4,8],maj7:[0,4,7,11],m7:[0,3,7,10],dom7:[0,4,7,10],halfDim:[0,3,6,10]};
const specs=[
 ['C','major','C E G',1],['F','major','F A C',1],['G','major','G B D',1],['D','major','D F# A',1],['Bb','major','Bb D F',1],
 ['Am','minor','A C E',1],['Dm','minor','D F A',1],['Em','minor','E G B',1],['Gm','minor','G Bb D',1],['Cm','minor','C Eb G',1],
 ['Cmaj7','maj7','C E G B',2],['Fmaj7','maj7','F A C E',2],['Gmaj7','maj7','G B D F#',2],['Bbmaj7','maj7','Bb D F A',2],
 ['Am7','m7','A C E G',2],['Dm7','m7','D F A C',2],['Em7','m7','E G B D',2],['Gm7','m7','G Bb D F',2],
 ['G7','dom7','G B D F',2],['C7','dom7','C E G Bb',2],['D7','dom7','D F# A C',2],['F7','dom7','F A C Eb',2],
 ['Bdim','dim','B D F',3],['Ddim','dim','D F Ab',3],['Caug','aug','C E G#',3],['Faug','aug','F A C#',3],['Bm7b5','halfDim','B D F A',3],['Em7b5','halfDim','E G Bb D',3]
];
const ROOT=(symbol)=>symbol.match(/^[A-G](?:#|b)?/)[0];
export const EXERCISES=specs.map(([symbol,quality,spelling,level])=>({id:symbol,symbol,quality,level,root:ROOT(symbol),notes:spelling.split(' '),expected:spelling.split(' ').map(n=>PITCH[n])}));
export function grade(exercise,selected){const chosen=new Set(selected.map(n=>((n%12)+12)%12)); const want=new Set(exercise.expected); const missing=[...want].filter(n=>!chosen.has(n));const extra=[...chosen].filter(n=>!want.has(n));return {correct:missing.length===0&&extra.length===0,missing,extra};}
export function questionSet(level,random=Math.random){const pool=level===1?EXERCISES.filter(e=>e.level===1):level===2?EXERCISES.filter(e=>e.level===2):EXERCISES.filter(e=>e.level===3);const shuffled=(items)=>{let a=[...items];for(let i=a.length-1;i>0;i--){let j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a}; if(level===3)return shuffled([...pool,...shuffled(EXERCISES.filter(e=>e.level<3)).slice(0,4)]);return shuffled(pool).slice(0,10);}
export const DEGREES={major:'1 · 3 · 5',minor:'1 · ♭3 · 5',dim:'1 · ♭3 · ♭5',aug:'1 · 3 · ♯5',maj7:'1 · 3 · 5 · 7',m7:'1 · ♭3 · 5 · ♭7',dom7:'1 · 3 · 5 · ♭7',halfDim:'1 · ♭3 · ♭5 · ♭7'};
export const PROGRESSION={id:'ii-v-i-c',title:'II – V – I en Do majeur',frames:[
 {symbol:'Dm7',voices:[{id:0,midi:62,note:'D4'},{id:1,midi:65,note:'F4'},{id:2,midi:69,note:'A4'},{id:3,midi:72,note:'C5'}]},
 {symbol:'G7',voices:[{id:0,midi:62,note:'D4'},{id:1,midi:65,note:'F4'},{id:2,midi:67,note:'G4'},{id:3,midi:71,note:'B4'}]},
 {symbol:'Cmaj7',voices:[{id:0,midi:64,note:'E4'},{id:1,midi:67,note:'G4'},{id:2,midi:71,note:'B4'},{id:3,midi:72,note:'C5'}]}
]};
export function checkProgression(p=PROGRESSION){return p.frames.every(f=>f.voices.length===4&&new Set(f.voices.map(v=>v.id)).size===4)&&p.frames.map(f=>f.voices.map(v=>v.id).join(',')).every(x=>x==='0,1,2,3');}
